# Rclone + 115 网盘挂载部署指南

本指南将教你如何在 Linux 服务器上安装 Rclone，配置 115 网盘，并将其挂载为本地目录，用于文件备份。

## 1. 安装 Rclone

在终端执行以下命令：

```bash
curl https://rclone.org/install.sh | sudo bash
```

## 2. 获取 115 Cookie

由于 115 登录需要 Cookie，你需要先在电脑浏览器上获取：

1.  打开 Chrome/Edge 浏览器，访问 [115.com](https://115.com/) 并登录。
2.  按 `F12` 打开开发者工具，切换到 `Network` (网络) 标签。
3.  刷新页面，点击左侧列表中第一个请求（通常是 `home` 或 `index`）。
4.  在右侧 `Headers` (请求头) 中找到 `Cookie`。
5.  复制整个 `Cookie` 字符串的值。

## 3. 配置 Rclone

运行配置命令：

```bash
rclone config
```

按以下步骤操作：

1.  输入 `n` (New remote) 新建配置。
2.  输入名称：`115`
3.  找到 **115** 对应的数字（输入 `115` 搜索更方便），按回车。
    *   注意：如果找不到 115，可能需要安装特定版本的 rclone 或者使用 docker（如有需要请告诉我）。
    *   **更通用的方法**：如果 Rclone 原生不支持 115，推荐使用 [alist](https://alist.nn.ci/) 将 115 转为 WebDAV，然后 Rclone 挂载 WebDAV。
    *   **(强烈推荐)** 使用 **Alist + Rclone** 方案，因为 115 的第三方 API 经常变动，Alist 维护得更好。

---

### 🌟 推荐方案：Alist + Rclone (最稳)

#### 第一步：安装 Alist

```bash
curl -fsSL "https://alist.nn.ci/v3.sh" | bash -s install
```

1.  安装完成后，查看管理员密码：`./alist admin`
2.  访问 `http://你的服务器IP:5244`
3.  登录后，点击 **存储** -> **添加** -> 选择 **115 Cloud**。
4.  填入你在步骤 2 获取的 Cookie（或者扫码登录）。
5.  挂载路径填 `/115`。

#### 第二步：配置 Rclone 连接 Alist

```bash
rclone config
```

1.  `n` (New remote) -> 名称 `115backup`
2.  选择 **WebDAV** (通常是列表里的 `WebDAV`)
3.  `url` 填: `http://127.0.0.1:5244/dav`
4.  `vendor` 选 `Other`
5.  `user` 填 `admin`
6.  `password` 填你 Alist 的密码
7.  其余直接回车默认。

## 4. 挂载到本地目录

现在把网盘挂载成一个文件夹：

```bash
# 创建挂载点
mkdir -p /mnt/115backup

# 后台挂载命令
nohup rclone mount 115backup:/115 /mnt/115backup \
 --cache-dir /tmp/rclone \
 --vfs-cache-mode full \
 --vfs-cache-max-age 1h \
 --vfs-read-chunk-size 16M \
 --vfs-read-chunk-size-limit 2G \
 --allow-other \
 > /dev/null 2>&1 &
```

## 5. 验证

```bash
df -h
ls /mnt/115backup
```

如果能看到 115 里的文件，恭喜你，挂载成功！🎉

---

## 6. 告诉机器人

挂载成功后，告诉机器人你的挂载路径：

**`/mnt/115backup/vault_backup`** (建议新建一个 vault_backup 文件夹)
